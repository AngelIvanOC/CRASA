import styled from "styled-components";
export const Title = styled.span`
  font-weight: 700;
  font-size: 30px;
  padding-bottom: ${(props) => props.$paddingbottom};
  color: ${(props) => props.$colortexto};
`;
