import { DashboardTemplate } from "../index";
export function Dashboard() {
  return <DashboardTemplate />;
}
